import { Controller } from "./MVC/controller.js";
Controller.init();
